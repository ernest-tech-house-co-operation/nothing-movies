import QtQuick 2.15
import QtQuick.Layouts 1.15

Rectangle {
    id: homeScreen
    color: "#0d0d0d"

    ListModel { id: trendingModel }
    ListModel { id: upcomingModel }

    Connections {
        target: tmdbBridge
        function onTrendingReady(movies) {
            trendingModel.clear()
            for (var i = 0; i < movies.length; i++) trendingModel.append(movies[i])
        }
        function onUpcomingReady(movies) {
            upcomingModel.clear()
            for (var i = 0; i < movies.length; i++) upcomingModel.append(movies[i])
        }
    }

    Component.onCompleted: {
        tmdbBridge.loadTrending()
        tmdbBridge.loadUpcoming()
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 24
        spacing: 24

        Text {
            text: "Home"
            color: "white"
            font.pixelSize: 28
            font.bold: true
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 8

            Text { text: "Trending"; color: "white"; font.pixelSize: 18; font.bold: true }

            ListView {
                Layout.fillWidth: true
                Layout.preferredHeight: 240
                orientation: ListView.Horizontal
                spacing: 12
                clip: true
                model: trendingModel

                delegate: MovieCard {
                    width: 150
                    height: 220
                    movieTitle: model.title
                    movieYear: model.year.toString()
                    posterUrl: model.posterUrl
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 8

            Text { text: "Upcoming"; color: "white"; font.pixelSize: 18; font.bold: true }

            ListView {
                Layout.fillWidth: true
                Layout.preferredHeight: 240
                orientation: ListView.Horizontal
                spacing: 12
                clip: true
                model: upcomingModel

                delegate: MovieCard {
                    width: 150
                    height: 220
                    movieTitle: model.title
                    movieYear: model.year.toString()
                    posterUrl: model.posterUrl
                }
            }
        }

        Item { Layout.fillHeight: true }
    }
}