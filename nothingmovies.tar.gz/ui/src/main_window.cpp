#include "ui/MainWindow.h"
#include "ui/TmdbBridge.h"
#include "ui/SearchBridge.h"
#include "ui/AppController.h"
#include "ui/PlayerPageWidget.h"

#include <QQuickView>
#include <QQmlEngine>
#include <QQmlContext>
#include <QUrl>
#include <QWidget>
#include <QStackedWidget>

// Static libs strip unreferenced resource initializers -- force it to run.
inline void initUiResources() {
    Q_INIT_RESOURCE(resources);
}

namespace ui {

MainWindow::MainWindow(TmdbBridge* tmdbBridge, SearchBridge* searchBridge, AppController* appController,
                        std::shared_ptr<queue_manager::Queue_managerModule> queueManager, QWidget* parent)
    : QMainWindow(parent) {
    initUiResources();

    setWindowTitle("Nothing Movies");
    resize(1280, 800);

    // Page 0: the existing QML app, completely unchanged.
    auto* quickView = new QQuickView();
    quickView->setResizeMode(QQuickView::SizeRootObjectToView);
    quickView->rootContext()->setContextProperty("tmdbBridge", tmdbBridge);
    quickView->rootContext()->setContextProperty("searchBridge", searchBridge);
    quickView->rootContext()->setContextProperty("appController", appController);
    quickView->setSource(QUrl(QStringLiteral("qrc:/qml/Main.qml")));

    QWidget* qmlContainer = QWidget::createWindowContainer(quickView, this);
    qmlContainer->setMinimumSize(800, 600);
    qmlContainer->setFocusPolicy(Qt::TabFocus);

    // Page 1: plain QWidget holding a raw native QWindow that mpv renders
    // into -- a separate native surface from the QQuickView above, not a
    // hole punched into it.
    playerPage_ = new PlayerPageWidget(std::move(queueManager), this);

    stack_ = new QStackedWidget(this);
    stack_->addWidget(qmlContainer);   // index 0
    stack_->addWidget(playerPage_);    // index 1
    setCentralWidget(stack_);

    connect(appController, &AppController::streamRequested, this,
            [this](const QString& title, const QString& url) {
                playerPage_->startStream(title, url);
                stack_->setCurrentIndex(1);
            });
    connect(appController, &AppController::stopRequested, this, [this]() {
        playerPage_->stopStream();
        stack_->setCurrentIndex(0);
    });
    connect(playerPage_, &PlayerPageWidget::backRequested, this, [this]() {
        stack_->setCurrentIndex(0);
    });
}

}
