#include "ui/PlayerPageWidget.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QWindow>
#include <QLabel>
#include <QPushButton>
#include <QTimer>

namespace ui {

PlayerPageWidget::PlayerPageWidget(std::shared_ptr<queue_manager::Queue_managerModule> queueManager,
                                   QWidget* parent)
    : QWidget(parent), queueManager_(std::move(queueManager)) {
    // Plain QWindow, NOT a QQuickWindow -- this is the native surface mpv
    // renders into. create() forces the platform window (and its
    // winId()) to exist before we hand that id to libmpv.
    videoWindow_ = new QWindow();
    videoWindow_->setFlags(Qt::FramelessWindowHint);
    videoWindow_->create();

    videoContainer_ = QWidget::createWindowContainer(videoWindow_, this);
    videoContainer_->setFocusPolicy(Qt::StrongFocus);

    player_.init(static_cast<int64_t>(videoWindow_->winId()));

    titleLabel_ = new QLabel(this);
    titleLabel_->setStyleSheet("color: white; font-size: 16px;");

    statusLabel_ = new QLabel(this);
    statusLabel_->setStyleSheet("color: #aaaaaa; font-size: 13px;");
    statusLabel_->hide();

    backButton_ = new QPushButton("< Back", this);
    connect(backButton_, &QPushButton::clicked, this, [this]() {
        stopStream();
        emit backRequested();
    });

    auto* topBar = new QHBoxLayout();
    topBar->addWidget(backButton_);
    topBar->addWidget(titleLabel_, /*stretch=*/1);
    topBar->addWidget(statusLabel_);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(8, 8, 8, 8);
    layout->addLayout(topBar);
    layout->addWidget(videoContainer_, /*stretch=*/1);

    setStyleSheet("background-color: #000000;");

    // Pumps mpv's event queue and, while a magnet is queued, checks
    // queue_manager for readyToPlay. 500ms matches queue_manager's own
    // documented polling cadence for torrent/download progress.
    timer_ = new QTimer(this);
    connect(timer_, &QTimer::timeout, this, &PlayerPageWidget::onTick);
    timer_->start(500);
}

PlayerPageWidget::~PlayerPageWidget() = default;

void PlayerPageWidget::setStatus(const QString& text) {
    statusLabel_->setText(text);
    statusLabel_->setVisible(!text.isEmpty());
}

void PlayerPageWidget::startStream(const QString& title, const QString& url) {
    titleLabel_->setText(title);
    waitingOnQueue_ = false;
    pendingQueueId_.clear();

    const std::string urlStd = url.toStdString();
    if (urlStd.rfind("magnet:", 0) == 0) {
        setStatus("Queuing torrent...");
        pendingQueueId_ = queueManager_->enqueueTorrent(title.toStdString(), urlStd);
        if (pendingQueueId_.empty()) {
            setStatus("Failed to queue torrent.");
            return;
        }
        waitingOnQueue_ = true;
    } else {
        // Plain HTTP(S) direct link -- no queue, straight into mpv.
        beginPlayback(urlStd);
    }
}

void PlayerPageWidget::beginPlayback(const std::string& path) {
    setStatus("Loading...");
    player_.load(path);
    player_.play();
}

void PlayerPageWidget::stopStream() {
    waitingOnQueue_ = false;
    pendingQueueId_.clear();
    player_.stop();
    setStatus(QString());
}

void PlayerPageWidget::onTick() {
    queueManager_->update();
    player_.update();

    if (waitingOnQueue_ && !pendingQueueId_.empty()) {
        const auto item = queueManager_->getItem(pendingQueueId_);
        if (item.state == queue_manager::QueueItemState::Error) {
            waitingOnQueue_ = false;
            setStatus("Torrent failed to start.");
        } else if (item.readyToPlay && !item.filePath.empty()) {
            waitingOnQueue_ = false;
            beginPlayback(item.filePath);
        } else {
            const int pct = static_cast<int>(item.progress * 100.0);
            setStatus(QString("Buffering... %1%").arg(pct));
        }
        return;
    }

    const auto status = player_.getStatus();
    if (status.state == player::PlaybackState::Playing && !status.buffering) {
        setStatus(QString());
    } else if (status.buffering) {
        setStatus("Buffering...");
    } else if (status.state == player::PlaybackState::Error) {
        setStatus("Playback error.");
    }
}

}  // namespace ui
