#pragma once
#include <QWidget>
#include <memory>
#include <string>

#include "player/player.h"
#include "queue_manager/queue_manager.h"

class QWindow;
class QLabel;
class QTimer;
class QPushButton;

namespace ui {

// Page 1 of MainWindow's QStackedWidget. Holds a raw QWindow embedded via
// createWindowContainer -- a plain native surface, separate from the QML
// QQuickView on page 0 -- that PlayerModule renders mpv video into.
//
// Flow: startStream(title, url). A magnet gets queued via queue_manager
// and polled every ~500ms until queue_manager reports readyToPlay (enough
// buffered near the front of the file for mpv to open it); a plain
// HTTP(S) url skips the queue and loads straight into mpv.
class PlayerPageWidget : public QWidget {
    Q_OBJECT
public:
    explicit PlayerPageWidget(std::shared_ptr<queue_manager::Queue_managerModule> queueManager,
                               QWidget* parent = nullptr);
    ~PlayerPageWidget() override;

public slots:
    void startStream(const QString& title, const QString& url);
    void stopStream();

signals:
    void backRequested();

private slots:
    void onTick();

private:
    void beginPlayback(const std::string& path);
    void setStatus(const QString& text);

    std::shared_ptr<queue_manager::Queue_managerModule> queueManager_;
    player::PlayerModule player_;

    QWindow* videoWindow_ = nullptr;
    QWidget* videoContainer_ = nullptr;
    QLabel* statusLabel_ = nullptr;
    QLabel* titleLabel_ = nullptr;
    QPushButton* backButton_ = nullptr;
    QTimer* timer_ = nullptr;

    bool waitingOnQueue_ = false;
    std::string pendingQueueId_;
};

}  // namespace ui
