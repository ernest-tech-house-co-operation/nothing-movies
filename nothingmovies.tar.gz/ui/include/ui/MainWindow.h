#pragma once
#include <QMainWindow>
#include <memory>
#include "queue_manager/queue_manager.h"

class QStackedWidget;

namespace ui {

class TmdbBridge;
class SearchBridge;
class AppController;
class PlayerPageWidget;

class MainWindow : public QMainWindow {
Q_OBJECT
public:
    explicit MainWindow(TmdbBridge* tmdbBridge, SearchBridge* searchBridge, AppController* appController,
                         std::shared_ptr<queue_manager::Queue_managerModule> queueManager,
                         QWidget* parent = nullptr);

private:
    QStackedWidget* stack_ = nullptr;
    PlayerPageWidget* playerPage_ = nullptr;
};

}
